def calculate_bungee_physics(y_pos, velocity, gravity, k, damping, rest_length):
    # Apply Gravity
    force = gravity
    
    # Apply Spring Force (Hooke's Law) if stretched
    displacement = y_pos - rest_length
    if displacement > 0:
        spring_force = -k * displacement
        force += spring_force

    new_velocity = (velocity + force) * damping
    new_y_pos = y_pos + new_velocity
    
    return new_y_pos, new_velocity