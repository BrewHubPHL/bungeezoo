import pygame
import random
import math
import os
from src.physics import calculate_bungee_physics

class CowSprite(pygame.sprite.Sprite):
    def __init__(self, image_path, splat_image_path, sound_path, splat_sound_path, x_pos, screen_height):
        super().__init__()
        self.x_pos = x_pos
        self.screen_height = screen_height # Remember the screen size!
        
        # --- Visual Setup ---
        try:
            img = pygame.image.load(image_path).convert_alpha()
            self.original_image = pygame.transform.smoothscale(img, (70, 70))
        except:
            self.original_image = pygame.Surface((70, 70))
            self.original_image.fill((255, 255, 255))

        # Splat Setup
        self.splat_image_original = pygame.Surface((90, 45), pygame.SRCALPHA)
        pygame.draw.ellipse(self.splat_image_original, (180, 0, 0), (0, 5, 90, 35))
        pygame.draw.ellipse(self.splat_image_original, (220, 0, 0), (10, 0, 70, 45))
        
        if os.path.exists(splat_image_path):
             try:
                s_img = pygame.image.load(splat_image_path).convert_alpha()
                self.splat_image_original = pygame.transform.smoothscale(s_img, (90, 45))
             except: pass

        self.image = self.original_image
        self.rect = self.image.get_rect(center=(x_pos, -200))

        # --- Audio ---
        self.moo_sound = None
        self.splat_sound = None
        if os.path.exists(sound_path):
            self.moo_sound = pygame.mixer.Sound(sound_path)
            self.moo_sound.set_volume(0.4) 
        if os.path.exists(splat_sound_path):
            self.splat_sound = pygame.mixer.Sound(splat_sound_path)

        # --- Init ---
        self.randomize_rope()
        self.respawn()

    def randomize_rope(self):
        # Calculates rope length based on ACTUAL screen height
        # Safe ropes are 30% to 80% of screen height
        # Deadly ropes are 90% to 110% of screen height (SPLAT!)
        min_len = int(self.screen_height * 0.3)
        max_len = int(self.screen_height * 1.05) # 1.05 means it hits the floor
        
        self.rest_length = random.randint(min_len, max_len) 
        self.k_stiffness = random.uniform(0.03, 0.05) 

    def respawn(self):
        self.is_splatted = False
        self.image = self.original_image
        
        # Reset to top with random delay offset
        start_y = random.randint(-600, -100)
        self.rect.centery = start_y
        self.y_float = float(start_y)
        self.vel = 0
        self.was_falling = True
        
        self.splat_timer = 0
        self.safety_timer = 0
        
        # Get a new rope for this specific jump
        self.randomize_rope()

    def update(self):
        # Calculate floor based on the height we were given
        floor_y = self.screen_height - 50

        # --- SPLATTED ---
        if self.is_splatted:
            self.splat_timer += 1
            if self.splat_timer > 60: 
                self.respawn()
            return

        # --- ALIVE ---
        self.safety_timer += 1
        # Randomize the life limit so they don't all reset in sync
        # Some survive 5 seconds, some survive 8
        life_limit = 300 + random.randint(0, 200) 
        if self.safety_timer > life_limit:
            self.respawn()
            return

        # Physics
        GRAVITY = 0.5
        DAMPING = 0.99
        self.y_float, self.vel = calculate_bungee_physics(
            self.y_float, self.vel, GRAVITY, self.k_stiffness, DAMPING, self.rest_length
        )

        # Check Collision
        if self.y_float >= floor_y:
            self.is_splatted = True
            self.vel = 0
            self.y_float = floor_y
            self.image = self.splat_image_original
            self.rect = self.image.get_rect(center=(self.x_pos, floor_y + 10))
            if self.splat_sound: self.splat_sound.play()
            return

        # Rotation
        swing_intensity = 15 + (abs(self.vel) * 2)
        angle = math.sin(pygame.time.get_ticks() * 0.005 + self.x_pos) * swing_intensity
        self.image = pygame.transform.rotate(self.original_image, angle)
        self.rect = self.image.get_rect(center=(self.x_pos, int(self.y_float)))

        # Audio
        is_falling = self.vel > 0
        if self.was_falling and not is_falling and self.rect.centery > (self.screen_height * 0.5):
            if random.random() < 0.3 and self.moo_sound:
                 self.moo_sound.play()
        self.was_falling = is_falling