# /// script
# title = BungeeZoo
# ///

import pygame
import sys
import random
import asyncio 

# --- 4. Mobile Loop ---
async def main():
    # Import and init INSIDE async for pygbag compatibility
    from src.sprites import CowSprite
    
    pygame.init()
    pygame.mixer.init()

    # Web-compatible resolution (matches pygbag config)
    WIDTH, HEIGHT = 1280, 720
    screen = pygame.display.set_mode((WIDTH, HEIGHT))

    # Hide the mouse cursor for a cleaner touch experience
    pygame.mouse.set_visible(False)

    pygame.display.set_caption("BungeeZoo") 
    clock = pygame.time.Clock()
    
    # Use default font (works in web)
    font = pygame.font.Font(None, 28)

    # --- 2. Assets ---
    character_images = [
        "assets/images/bear.png",
        "assets/images/bull.png",
        "assets/images/cow.png",
        "assets/images/fishbowl.png",
        "assets/images/milk-free.png",
        "assets/images/monkey.png",
        "assets/images/monkey2.png",
        "assets/images/rabbit.png"
    ]
    splat_img = "assets/images/cow_splat.png"
    moo_snd = "assets/sounds/moo.wav"
    splat_snd = "assets/sounds/splat.wav"

    # --- 3. Create Herd ---
    all_sprites = pygame.sprite.Group()
    characters = []

    num_chars = len(character_images)
    # Reduce padding slightly for narrower phone screens
    padding = 40 
    step = (WIDTH - (padding * 2)) // (max(1, num_chars - 1))

    for i in range(num_chars):
        x_pos = padding + (i * step)
        img_path = character_images[i]
        # Pass HEIGHT so they know how deep to fall
        char = CowSprite(img_path, splat_img, moo_snd, splat_snd, x_pos, HEIGHT)
        all_sprites.add(char)
        characters.append(char)

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            
            # --- INPUT HANDLER (Keyboard + Touch) ---
            should_reset = False
            
            # 1. Keyboard (Desktop)
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    pygame.quit()
                    sys.exit()
                if event.key == pygame.K_r:
                    should_reset = True
            
            # 2. Touch/Mouse (Mobile)
            # FINGERDOWN = Touching screen
            # MOUSEBUTTONDOWN = Clicking with mouse (or tap on some devices)
            if event.type == pygame.FINGERDOWN or event.type == pygame.MOUSEBUTTONDOWN:
                should_reset = True
                
            if should_reset:
                for char in characters: char.respawn()

        all_sprites.update()

        screen.fill((135, 206, 235)) 
        
        # Draw Floor (Height - 50)
        floor_y = HEIGHT - 50
        pygame.draw.rect(screen, (34, 139, 34), (0, floor_y, WIDTH, 50)) 

        # Draw Ropes
        for char in characters:
            if not char.is_splatted:
                anchor = (char.x_pos, 0)
                rope_color = (139, 69, 19)
                
                if char.rect.centery < char.rest_length:
                    mid_x = char.x_pos + random.randint(-5, 5)
                    mid_y = char.rect.centery // 2
                    points = [anchor, (mid_x - 10, mid_y), (mid_x + 10, mid_y + 20), char.rect.midtop]
                    pygame.draw.lines(screen, rope_color, False, points, 2)
                else:
                    pygame.draw.line(screen, rope_color, anchor, char.rect.midtop, 2)

        all_sprites.draw(screen)
        
        # Draw a tiny "Tap to Reset" hint at the top
        text = font.render("Tap to Reset", True, (255, 255, 255))
        screen.blit(text, (WIDTH//2 - text.get_width()//2, 10))

        pygame.display.flip()
        clock.tick(60)
        await asyncio.sleep(0)

if __name__ == "__main__":
    asyncio.run(main())