# Placeholder for moo.wav
# Add a .wav file with a cow "moo" sound effect for that authentic 95' feel
# The game will run silently if this sound is not found
